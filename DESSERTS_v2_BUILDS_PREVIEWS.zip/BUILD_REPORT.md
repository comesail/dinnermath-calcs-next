# BUILD REPORT — Desserts v2

Generated: 2025-11-08T21:12:03.074084Z

Versions:
- Engine: engine.v2.js (Desserts AE 1.00/0.75/0.50)
- Runner: runner.v2.js
- Skin: EDITORIAL-SHARED.html (based on uploaded v1.4; loader tags injected)

Rules applied:
- Event Length hidden
- Leftovers UI removed; Hybrid note present under Results
- Dessert yield locked to 1.00 (no blocking)
- Scoop-size/style display-only; Toppings bar +10% cushion

Summary:

- BUILT: 9 → cheesecake, cookies, cupcakes, doughnuts, pies-by-slice, brownies, layer-cake-by-slice, macarons, sheet-cake-by-slice

- PARTIAL: 3 → cobbler-crisps-crumbles, mini-desserts, puddings-custard-mousse


Missing fields per PARTIAL slug (ignores raw_to_cooked_yield by lock):

- cobbler-crisps-crumbles: missing adult_cooked_baseline
- mini-desserts: missing adult_cooked_baseline
- puddings-custard-mousse: missing primary_purchase_unit